package com.microservices.userservice.model;

public enum SessionStatus {
    ACTIVE,
    ENDED
}
