package com.microservices.productservice.dto;

public enum SessionStatus {
    ACTIVE,
    ENDED
}
